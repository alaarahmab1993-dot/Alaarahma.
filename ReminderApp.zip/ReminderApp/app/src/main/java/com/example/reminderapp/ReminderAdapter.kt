package com.example.reminderapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.reminderapp.data.Reminder
import com.example.reminderapp.databinding.ItemReminderBinding

class ReminderAdapter(
    private val onToggle: (Reminder, Boolean) -> Unit,
    private val onDelete: (Reminder) -> Unit,
    private val onEdit: (Reminder) -> Unit
) : ListAdapter<Reminder, ReminderAdapter.ReminderViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReminderViewHolder {
        val binding = ItemReminderBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ReminderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ReminderViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ReminderViewHolder(private val binding: ItemReminderBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(reminder: Reminder) {
            binding.textMessage.text = reminder.message
            binding.textDetails.text = String.format(
                "%02d:%02d  •  %d مرة/يوم",
                reminder.hour, reminder.minute, reminder.timesPerDay
            )

            // نتجنب استدعاء onToggle أثناء عملية إعادة الربط
            binding.switchEnabled.setOnCheckedChangeListener(null)
            binding.switchEnabled.isChecked = reminder.enabled
            binding.switchEnabled.setOnCheckedChangeListener { _, isChecked ->
                onToggle(reminder, isChecked)
            }

            binding.buttonDelete.setOnClickListener { onDelete(reminder) }
            binding.root.setOnClickListener { onEdit(reminder) }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Reminder>() {
            override fun areItemsTheSame(old: Reminder, new: Reminder) = old.id == new.id
            override fun areContentsTheSame(old: Reminder, new: Reminder) = old == new
        }
    }
}
