package com.example.reminderapp

import android.Manifest
import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.NumberPicker
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.reminderapp.alarm.AlarmScheduler
import com.example.reminderapp.data.AppDatabase
import com.example.reminderapp.data.Reminder
import com.example.reminderapp.databinding.ActivityMainBinding
import com.example.reminderapp.databinding.DialogAddReminderBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ReminderAdapter
    private val dao by lazy { AppDatabase.getInstance(this).reminderDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        NotificationHelper.createChannel(this)
        requestNotificationPermissionIfNeeded()
        checkExactAlarmPermission()

        adapter = ReminderAdapter(
            onToggle = { reminder, enabled -> onToggleReminder(reminder, enabled) },
            onDelete = { reminder -> onDeleteReminder(reminder) },
            onEdit = { reminder -> showAddEditDialog(reminder) }
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener { showAddEditDialog(null) }

        lifecycleScope.launch {
            dao.getAllFlow().collect { list ->
                adapter.submitList(list)
                binding.emptyView.visibility =
                    if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }

    private fun onToggleReminder(reminder: Reminder, enabled: Boolean) {
        lifecycleScope.launch {
            val updated = reminder.copy(enabled = enabled)
            dao.update(updated)
            if (enabled) {
                AlarmScheduler.scheduleReminder(this@MainActivity, updated)
            } else {
                AlarmScheduler.cancelReminder(this@MainActivity, updated)
            }
        }
    }

    private fun onDeleteReminder(reminder: Reminder) {
        lifecycleScope.launch {
            AlarmScheduler.cancelReminder(this@MainActivity, reminder)
            dao.delete(reminder)
        }
        Toast.makeText(this, "تم الحذف", Toast.LENGTH_SHORT).show()
    }

    /** يفتح نافذة لإضافة تذكير جديد، أو تعديل تذكير موجود إن تم تمريره */
    private fun showAddEditDialog(existing: Reminder?) {
        val dialogBinding = DialogAddReminderBinding.inflate(layoutInflater)
        dialogBinding.editMessage.setText(existing?.message ?: "")

        var pickedHour = existing?.hour ?: 8
        var pickedMinute = existing?.minute ?: 0

        dialogBinding.buttonPickTime.text = formatTime(pickedHour, pickedMinute)
        dialogBinding.buttonPickTime.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                pickedHour = h
                pickedMinute = m
                dialogBinding.buttonPickTime.text = formatTime(h, m)
            }, pickedHour, pickedMinute, true).show()
        }

        dialogBinding.pickerTimesPerDay.minValue = 1
        dialogBinding.pickerTimesPerDay.maxValue = 24
        dialogBinding.pickerTimesPerDay.value = existing?.timesPerDay ?: 1

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة تذكير" else "تعديل التذكير")
            .setView(dialogBinding.root)
            .setPositiveButton("حفظ") { _, _ ->
                val text = dialogBinding.editMessage.text.toString().trim()
                if (text.isEmpty()) {
                    Toast.makeText(this, "يرجى كتابة نص التذكير", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val timesPerDay = dialogBinding.pickerTimesPerDay.value

                lifecycleScope.launch {
                    if (existing == null) {
                        val newReminder = Reminder(
                            message = text,
                            hour = pickedHour,
                            minute = pickedMinute,
                            timesPerDay = timesPerDay,
                            enabled = true
                        )
                        val newId = dao.insert(newReminder)
                        AlarmScheduler.scheduleReminder(this@MainActivity, newReminder.copy(id = newId.toInt()))
                    } else {
                        val updated = existing.copy(
                            message = text,
                            hour = pickedHour,
                            minute = pickedMinute,
                            timesPerDay = timesPerDay
                        )
                        dao.update(updated)
                        AlarmScheduler.scheduleReminder(this@MainActivity, updated)
                    }
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun formatTime(hour: Int, minute: Int): String =
        String.format("%02d:%02d", hour, minute)

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001
                )
            }
        }
    }

    /** على أندرويد 12+ نحتاج إذنًا خاصًا لجدولة إشعارات دقيقة بالوقت */
    private fun checkExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms()) {
                AlertDialog.Builder(this)
                    .setTitle("إذن مطلوب")
                    .setMessage("لكي تصل التذكيرات في وقتها بالضبط، يرجى تفعيل إذن \"الإنذارات الدقيقة\" للتطبيق.")
                    .setPositiveButton("فتح الإعدادات") { _, _ ->
                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = Uri.parse("package:$packageName")
                        }
                        startActivity(intent)
                    }
                    .setNegativeButton("لاحقًا", null)
                    .show()
            }
        }
    }
}
