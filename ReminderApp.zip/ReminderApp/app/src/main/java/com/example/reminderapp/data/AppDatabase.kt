package com.example.reminderapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Reminder::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // العبارات الافتراضية المطلوبة من المستخدم
        private val defaultReminders = listOf(
            Reminder(message = "حان وقت قراءة ورد من القرآن", hour = 8, minute = 0, timesPerDay = 1),
            Reminder(message = "لا تنسَ الاستغفار", hour = 12, minute = 0, timesPerDay = 3),
            Reminder(message = "لم تقم اليوم برياضة", hour = 18, minute = 0, timesPerDay = 1),
            Reminder(message = "اترك الهاتف قليلاً", hour = 21, minute = 0, timesPerDay = 2)
        )

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "reminder_db"
                ).build()
                INSTANCE = instance
                // تعبئة القائمة الافتراضية عند أول إنشاء لقاعدة البيانات فقط (إن كانت فارغة)
                CoroutineScope(Dispatchers.IO).launch {
                    val dao = instance.reminderDao()
                    if (dao.getAllOnce().isEmpty()) {
                        defaultReminders.forEach { dao.insert(it) }
                    }
                }
                instance
            }
        }
    }
}
