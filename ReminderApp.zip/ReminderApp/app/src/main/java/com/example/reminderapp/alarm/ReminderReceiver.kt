package com.example.reminderapp.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.reminderapp.NotificationHelper
import com.example.reminderapp.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_REMINDER_ID = "extra_reminder_id"
        const val EXTRA_SLOT = "extra_slot"
        const val EXTRA_MESSAGE = "extra_message"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getIntExtra(EXTRA_REMINDER_ID, -1)
        val slot = intent.getIntExtra(EXTRA_SLOT, 0)
        val message = intent.getStringExtra(EXTRA_MESSAGE)

        if (reminderId == -1) return

        // نعرض الإشعار مباشرة إن توفرت العبارة ضمن الـ Intent
        if (message != null) {
            NotificationHelper.show(context, reminderId * 100 + slot, message)
        }

        // نعيد الجدولة لليوم التالي، والتأكد أن التذكير لا يزال مفعلاً في قاعدة البيانات
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.getInstance(context).reminderDao()
                val reminder = dao.getById(reminderId)
                if (reminder != null && reminder.enabled) {
                    if (message == null) {
                        NotificationHelper.show(context, reminderId * 100 + slot, reminder.message)
                    }
                    AlarmScheduler.rescheduleSlotForNextDay(
                        context, reminderId, slot, System.currentTimeMillis()
                    )
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
