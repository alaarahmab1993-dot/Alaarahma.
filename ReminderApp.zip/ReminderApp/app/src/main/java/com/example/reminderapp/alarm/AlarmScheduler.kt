package com.example.reminderapp.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.reminderapp.data.Reminder
import java.util.Calendar

/**
 * مسؤول عن جدولة وإلغاء الإشعارات (Alarms) الخاصة بكل تذكير.
 * كل تذكير قد يظهر أكثر من مرة في اليوم (timesPerDay)، لذلك يتم توزيع
 * الأوقات بالتساوي بدءًا من hour:minute على مدار 24 ساعة.
 *
 * ملاحظة: كل إشعار يُعاد جدولة نفسه ليوم غد داخل ReminderReceiver،
 * لأن الأنظمة الحديثة لا تضمن دقة الإشعارات المتكررة (setRepeating)،
 * بينما setExactAndAllowWhileIdle + إعادة الجدولة يعطي دقة أعلى.
 */
object AlarmScheduler {

    private const val SLOT_MULTIPLIER = 100 // مساحة لأكواد الطلبات الفرعية لكل تذكير

    fun scheduleReminder(context: Context, reminder: Reminder) {
        cancelReminder(context, reminder) // نلغي أي جدولة سابقة أولاً

        if (!reminder.enabled) return

        val intervalMinutes = (24 * 60) / reminder.timesPerDay.coerceAtLeast(1)

        for (slot in 0 until reminder.timesPerDay) {
            val triggerTime = nextTriggerTimeMillis(reminder.hour, reminder.minute, slot * intervalMinutes)
            scheduleExactAlarm(context, reminder, slot, triggerTime)
        }
    }

    /** يُستدعى من الـ Receiver بعد إطلاق إشعار كي يعاد جدولته بعد 24 ساعة بالضبط */
    fun rescheduleSlotForNextDay(context: Context, reminderId: Int, slot: Int, previousTriggerTime: Long) {
        val nextTrigger = previousTriggerTime + AlarmManager.INTERVAL_DAY
        val intent = buildIntent(context, reminderId, slot)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(reminderId, slot), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setExact(context, nextTrigger, pendingIntent)
    }

    fun cancelReminder(context: Context, reminder: Reminder) {
        // نلغي حتى 96 فتحة محتملة (أكبر من أي عدد معقول لمرات الظهور في اليوم)
        for (slot in 0 until 96) {
            val intent = buildIntent(context, reminder.id, slot)
            val pendingIntent = PendingIntent.getBroadcast(
                context, requestCode(reminder.id, slot), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)
        }
    }

    private fun scheduleExactAlarm(context: Context, reminder: Reminder, slot: Int, triggerTime: Long) {
        val intent = buildIntent(context, reminder.id, slot, reminder.message)
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode(reminder.id, slot), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setExact(context, triggerTime, pendingIntent)
    }

    private fun setExact(context: Context, triggerTime: Long, pendingIntent: PendingIntent) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            // بدون إذن الجدولة الدقيقة، نستخدم بديلاً غير دقيق تمامًا لكنه يعمل
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        }
    }

    private fun buildIntent(context: Context, reminderId: Int, slot: Int, message: String? = null): Intent {
        return Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_REMINDER_ID, reminderId)
            putExtra(ReminderReceiver.EXTRA_SLOT, slot)
            if (message != null) putExtra(ReminderReceiver.EXTRA_MESSAGE, message)
        }
    }

    private fun requestCode(reminderId: Int, slot: Int) = reminderId * SLOT_MULTIPLIER + slot

    private fun nextTriggerTimeMillis(hour: Int, minute: Int, offsetMinutes: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MINUTE, offsetMinutes)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }
}
