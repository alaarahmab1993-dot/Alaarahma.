package com.example.reminderapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * يمثل تذكيرًا واحدًا.
 * hour / minute: أول وقت يبدأ فيه ظهور الإشعار خلال اليوم.
 * timesPerDay: عدد مرات ظهور الإشعار خلال اليوم (يتم توزيعها بالتساوي بدءًا من hour:minute).
 * enabled: هل التذكير مفعل أم موقوف مؤقتًا.
 */
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val message: String,
    val hour: Int,
    val minute: Int,
    val timesPerDay: Int,
    val enabled: Boolean = true
)
